# NFL Predictor Lite — Hosted Ready

Deploy a phone-friendly PWA with a single click on Render, or via Fly.io/Docker.

## Option A: One‑click on Render (recommended)
1. Create a **new GitHub repo** and upload this folder’s contents.
2. Go to https://render.com → **New** → **Blueprint** → pick your repo, select `render.yaml`.
3. Click **Deploy**. (Free plan works.)
4. When live, visit your Render URL on iPhone → **Share** → **Add to Home Screen**.

## Option B: Render (manual Web Service)
1. Create a new **Web Service** from your GitHub repo.
2. Environment: **Python**
3. Build Command: `pip install -r requirements.txt`
4. Start Command: `gunicorn server:app --bind 0.0.0.0:$PORT --timeout 120`

## Option C: Fly.io (Docker‑style)
```bash
flyctl launch        # accepts defaults, creates app + fly.toml
flyctl deploy        # deploys
flyctl open          # open the URL
```
- If you prefer Docker: `docker build -t nfl-lite . && docker run -p 5000:5000 nfl-lite`

## Using the App
- Home route `/` serves the PWA UI.
- API: `/api/predict?season=2025&week=7`

**Note:** No API keys needed; weather via Open‑Meteo, stats via `nfl_data_py`.
