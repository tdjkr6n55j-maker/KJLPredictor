
from flask import Flask, jsonify, send_from_directory, request
from pathlib import Path
import pandas as pd, numpy as np
from datetime import timezone
import requests
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline

app = Flask(__name__, static_folder="static", static_url_path="/static")

STADIUMS = pd.DataFrame([
    {"team":"ARI","lat":33.5276,"lon":-112.2626,"outdoors":False},
    {"team":"ATL","lat":33.7554,"lon":-84.4008,"outdoors":False},
    {"team":"BAL","lat":39.2779,"lon":-76.6229,"outdoors":True},
    {"team":"BUF","lat":42.7738,"lon":-78.7869,"outdoors":True},
    {"team":"CAR","lat":35.2251,"lon":-80.8531,"outdoors":True},
    {"team":"CHI","lat":41.8623,"lon":-87.6167,"outdoors":True},
    {"team":"CIN","lat":39.0954,"lon":-84.5161,"outdoors":True},
    {"team":"CLE","lat":41.5061,"lon":-81.6995,"outdoors":True},
    {"team":"DAL","lat":32.7473,"lon":-97.0945,"outdoors":False},
    {"team":"DEN","lat":39.7439,"lon":-105.0201,"outdoors":True},
    {"team":"DET","lat":42.3390,"lon":-83.0456,"outdoors":False},
    {"team":"GB","lat":44.5013,"lon":-88.0622,"outdoors":True},
    {"team":"HOU","lat":29.6847,"lon":-95.4107,"outdoors":False},
    {"team":"IND","lat":39.7601,"lon":-86.1639,"outdoors":False},
    {"team":"JAX","lat":30.3239,"lon":-81.6373,"outdoors":True},
    {"team":"KC","lat":39.0490,"lon":-94.4839,"outdoors":True},
    {"team":"LV","lat":36.0909,"lon":-115.1833,"outdoors":False},
    {"team":"LAC","lat":33.9535,"lon":-118.3387,"outdoors":False},
    {"team":"LAR","lat":33.9535,"lon":-118.3387,"outdoors":False},
    {"team":"MIA","lat":25.9580,"lon":-80.2389,"outdoors":True},
    {"team":"MIN","lat":44.9736,"lon":-93.2571,"outdoors":False},
    {"team":"NE","lat":42.0909,"lon":-71.2643,"outdoors":True},
    {"team":"NO","lat":29.9509,"lon":-90.0816,"outdoors":False},
    {"team":"NYG","lat":40.8135,"lon":-74.0745,"outdoors":True},
    {"team":"NYJ","lat":40.8135,"lon":-74.0745,"outdoors":True},
    {"team":"PHI","lat":39.9008,"lon":-75.1675,"outdoors":True},
    {"team":"PIT","lat":40.4468,"lon":-80.0158,"outdoors":True},
    {"team":"SEA","lat":47.5952,"lon":-122.3316,"outdoors":True},
    {"team":"SF","lat":37.4030,"lon":-121.9700,"outdoors":True},
    {"team":"TB","lat":27.9759,"lon":-82.5033,"outdoors":True},
    {"team":"TEN","lat":36.1665,"lon":-86.7713,"outdoors":True},
    {"team":"WAS","lat":38.9077,"lon":-76.8645,"outdoors":True}
]).set_index("team")

def fetch_schedule(season: int):
    import nfl_data_py as nfl
    sched = nfl.import_schedules([season])
    sched = sched[sched["season_type"].isin(["REG","POST"])].copy()
    cols = ["game_id","week","gameday","gametime","home_team","away_team","season",
            "season_type","home_score","away_score"]
    sched = sched[cols]
    kickoff = pd.to_datetime(sched["gameday"].astype(str) + " " + sched["gametime"].fillna("20:00"), errors="coerce")
    sched["kickoff_et"] = kickoff.dt.tz_localize("US/Eastern", nonexistent="shift_forward", ambiguous="NaT")
    return sched

def fetch_team_features(seasons):
    import nfl_data_py as nfl
    pbp = nfl.import_pbp_data(seasons, downcast=True, cache=True)
    pbp = pbp[pbp["play_type"].isin(["pass","run"])]
    grp = pbp.groupby(["season","week","posteam"])
    off = grp.agg(epa=("epa","mean"), sr=("success","mean"), passrate=("pass","mean")).reset_index().rename(columns={"posteam":"team"})
    grp_d = pbp.groupby(["season","week","defteam"])
    de = grp_d.agg(epa=("epa","mean"), sr=("success","mean"), passrate=("pass","mean")).reset_index().rename(columns={"defteam":"team"})
    off = off.add_prefix("off_"); off.rename(columns={"off_season":"season","off_week":"week","off_team":"team"}, inplace=True)
    de  = de.add_prefix("def_"); de.rename(columns={"def_season":"season","def_week":"week","def_team":"team"}, inplace=True)
    tw = pd.merge(off, de, on=["season","week","team"], how="outer").sort_values(["team","season","week"])
    for f in ["off_epa","off_sr","off_passrate","def_epa","def_sr","def_passrate"]:
        tw[f+"_r5"] = tw.groupby("team")[f].apply(lambda s: s.shift(1).rolling(5, min_periods=3).mean())
        tw[f+"_r5"] = tw[f+"_r5"].fillna(tw[f+"_r5"].mean())
    return tw

def open_meteo(lat, lon, kickoff_ts):
    date = kickoff_ts.astimezone(timezone.utc).date().isoformat()
    url = ("https://api.open-meteo.com/v1/forecast"
           f"?latitude={lat}&longitude={lon}"
           "&hourly=temperature_2m,precipitation,wind_speed_10m"
           f"&start_date={date}&end_date={date}&timezone=UTC")
    r = requests.get(url, timeout=20); r.raise_for_status()
    js = r.json()
    times = pd.to_datetime(js["hourly"]["time"]).dt.tz_localize("UTC")
    df = pd.DataFrame({"time":times,"temp_c":js["hourly"]["temperature_2m"],
                       "precip_mm":js["hourly"]["precipitation"],"wind_mps":js["hourly"]["wind_speed_10m"]})
    idx = (df["time"] - kickoff_ts.astimezone(timezone.utc)).abs().idxmin()
    row = df.loc[idx]
    return float(row["temp_c"]), float(row["wind_mps"]), float(row["precip_mm"])

def build_train_frame(sched, tw):
    def merge_side(s, side):
        suf = "_h" if side=="home" else "_a"; key = "home_team" if side=="home" else "away_team"
        x = s.merge(tw.add_suffix(suf), left_on=["season","week", key], right_on=["season","week","team"+suf], how="left")
        x.drop(columns=[c for c in x.columns if c.endswith("team"+suf)], inplace=True); return x
    df = merge_side(sched, "home"); df = merge_side(df, "away")
    for base in ["off_epa_r5","off_sr_r5","off_passrate_r5","def_epa_r5","def_sr_r5","def_passrate_r5"]:
        df[base.replace("_r5","_diff")] = df[base+"_h"] - df[base+"_a"]
    df["home_win"] = (df["home_score"] > df["away_score"]).astype(int)
    return df

def make_model(train_df):
    feats = [c for c in train_df.columns if c.endswith("_diff")]
    X = train_df[feats].fillna(0).values; y = train_df["home_win"].values
    pipe = Pipeline([("scaler", StandardScaler()), ("logit", LogisticRegression(max_iter=200))])
    pipe.fit(X, y)
    return pipe, feats

def predict_week(season:int, week:int):
    # Train quickly on prior seasons only
    seasons = list(range(2015, season))
    tw = fetch_team_features(seasons)
    sched_all = pd.concat([fetch_schedule(y) for y in seasons], ignore_index=True)
    train = build_train_frame(sched_all.dropna(subset=["home_score","away_score"]), tw)
    model, feats = make_model(train)

    # Build this season's week features
    target_sched = fetch_schedule(season)
    wk = target_sched[(target_sched["season"]==season) & (target_sched["week"]==week)].copy()
    # Join rolling features from this season only
    tw_cur = fetch_team_features([season])
    def merge_side(s, side):
        suf = "_h" if side=="home" else "_a"; key = "home_team" if side=="home" else "away_team"
        x = s.merge(tw_cur.add_suffix(suf), left_on=["season","week", key], right_on=["season","week","team"+suf], how="left")
        x.drop(columns=[c for c in x.columns if c.endswith("team"+suf)], inplace=True); return x
    wk = merge_side(wk, "home"); wk = merge_side(wk, "away")
    for base in ["off_epa_r5","off_sr_r5","off_passrate_r5","def_epa_r5","def_sr_r5","def_passrate_r5"]:
        wk[base.replace("_r5","_diff")] = wk[base+"_h"] - wk[base+"_a"]

    # Weather
    wk["temp_c"]=np.nan; wk["wind_mps"]=np.nan; wk["precip_mm"]=np.nan; wk["is_outdoors"]=np.nan
    for i, row in wk.iterrows():
        home = row["home_team"]; ko = row["kickoff_et"]
        if pd.isna(ko) or home not in STADIUMS.index: continue
        st = STADIUMS.loc[home]
        try:
            t,w,p = open_meteo(st["lat"], st["lon"], ko.to_pydatetime())
            wk.at[i,"temp_c"]=t; wk.at[i,"wind_mps"]=w; wk.at[i,"precip_mm"]=p; wk.at[i,"is_outdoors"]=bool(st["outdoors"])
        except Exception:
            pass

    X = wk[[c for c in wk.columns if c.endswith("_diff")]].fillna(0).values
    home_wp = model.predict_proba(X)[:,1]
    out = []
    for i, r in wk.iterrows():
        out.append({
            "game_id": r["game_id"],
            "kickoff_et": str(r["kickoff_et"]),
            "away": r["away_team"],
            "home": r["home_team"],
            "home_wp": float(home_wp[list(wk.index).index(i)]),
            "away_wp": float(1.0 - home_wp[list(wk.index).index(i)]),
            "temp_c": None if pd.isna(r["temp_c"]) else float(r["temp_c"]),
            "wind_mps": None if pd.isna(r["wind_mps"]) else float(r["wind_mps"]),
            "precip_mm": None if pd.isna(r["precip_mm"]) else float(r["precip_mm"]),
            "is_outdoors": bool(r["is_outdoors"]) if not pd.isna(r["is_outdoors"]) else None
        })
    return out

@app.route("/")
def index():
    return send_from_directory("static","index.html")

@app.route("/manifest.webmanifest")
def manifest():
    return send_from_directory("static","manifest.webmanifest")

@app.route("/sw.js")
def sw():
    return send_from_directory("static","sw.js")

@app.route("/api/predict")
def api_predict():
    try:
        season = int(request.args.get("season", "2025"))
        week = int(request.args.get("week", "7"))
        data = predict_week(season, week)
        return jsonify({"ok": True, "season": season, "week": week, "games": data})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
