
const CACHE = 'nfl-lite-v1';
self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(['/','/static/index.html','/manifest.webmanifest','/static/icon-192.png','/static/icon-512.png'])));
});
self.addEventListener('fetch', e => {
  if (e.request.method !== 'GET') return;
  e.respondWith(caches.match(e.request).then(r => r || fetch(e.request)));
});
