# NFL Predictor Lite (Mobile PWA)

A minimal phone-friendly app with a tiny Flask API and a responsive front-end you can **Add to Home Screen** on iPhone.

## Run locally
```bash
python -m venv .venv && . .venv/bin/activate
pip install -r requirements.txt
python server.py
```
Open http://localhost:5000 on your phone (same Wi‑Fi; use your computer's IP) and tap **Share → Add to Home Screen**.

## Deploy (one-file server + static)
- Works on Render, Railway, Fly.io or any Python host. Set start command to `python server.py`.
- No keys required. Weather via Open‑Meteo; stats via `nfl_data_py`.

## Notes
- Model is a simple, transparent logistic regression trained on prior seasons each run.
- For speed, this "Lite" app omits heavy extras (XGBoost, market/injury CSVs). Use the full project if you need them.
